<?php
$title = 'SALAAM 🚍 ';
//E-Ticketing System For Railway
$supervisor_name = "Eng:Abdirahman";
$developer_name = "New Generation Team";
$developer_matric = "SMBT";
